package com.example.currencyexchangeapp.models



data class Apidata(
    var result: Double
)
