package com.example.userenquiryapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView


class DbListAdapter(val dataList:ArrayList<UserData> , private val onItemLongClickListener: OnItemLongClickListener) : RecyclerView.Adapter<DbListAdapter.UserViewHolder>(){

    class UserViewHolder(itemView:View):RecyclerView.ViewHolder(itemView){
        val listFormate:LinearLayout=itemView.findViewById(R.id.list_formate)

    }

    ///////interface for custom listener at recyclerview
    interface OnItemLongClickListener {
        fun onItemLongClick(position: Int)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserViewHolder {
         val item=LayoutInflater.from(parent.context).inflate(R.layout.history_list_formate,parent,false)
         return UserViewHolder(item)

    }

    override fun getItemCount(): Int {
         return dataList.size
    }

    /////delete one item from list
    fun removeItem(position: Int) {
        if (position in 0 until dataList.size) {
            dataList.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    override fun onBindViewHolder(holder: UserViewHolder, position: Int) {
        val currentItem = dataList[position]

        val firstName = currentItem.firstName ?: ""
        val middleName = currentItem.middleName ?: ""
        val lastName = currentItem.lastName ?: ""

        val fullname = "$firstName $middleName $lastName"

        val name: TextView = holder.itemView.findViewById(R.id.lv_userName)
        val mobile: TextView = holder.itemView.findViewById(R.id.lv_mobileNo)
        val email: TextView = holder.itemView.findViewById(R.id.lv_emailId)
        val dob: TextView = holder.itemView.findViewById(R.id.lv_Dob)
        val gender: TextView = holder.itemView.findViewById(R.id.lv_gender)
        val technology: TextView = holder.itemView.findViewById(R.id.lv_technology)

        name.text = fullname
        mobile.text = currentItem.mobileNumber
        email.text = currentItem.emailId
        dob.text = currentItem.dateOfBirth
        gender.text = currentItem.gender
        technology.text = currentItem.selectedLanguages

        holder.itemView.setOnLongClickListener {
            onItemLongClickListener.onItemLongClick(position)
            false
        }
    }




}

