package com.example.userenquiryapp

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.SharedPreferences.Editor
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.viewmodel.CreationExtras
import com.example.userenquiryapp.databinding.ActivitySignUpBinding

class SignUpActivity : AppCompatActivity() {
    lateinit var binding: ActivitySignUpBinding
    lateinit var signPrefrence:SharedPreferences
    lateinit var signEditor:Editor

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivitySignUpBinding.inflate(layoutInflater)
        setContentView(binding.root)

        signPrefrence=getSharedPreferences("SignUp_data",Context.MODE_PRIVATE)
        signEditor=signPrefrence.edit()

       binding.nameSignup.editText!!.addTextChangedListener {
           binding.nameSignup.error=null
       }
        binding.emailSignup.editText!!.addTextChangedListener {
            binding.emailSignup.error=null
        }
        binding.passwordSignup.editText!!.addTextChangedListener {
            binding.passwordSignup.error=null
        }
        binding.confirmPassSignup.editText!!.addTextChangedListener {
            binding.confirmPassSignup.error=null
        }

        binding.registerBtnSignup.setOnClickListener {
            if(binding.nameSignup.editText!!.text.toString().isEmpty()){
                binding.nameSignup.error="*Required field"
            }
            if(!isValidEmail(binding.emailSignup.editText!!.text)){
             binding.emailSignup.error="*Invalid email"
            }
            if(binding.passwordSignup.editText!!.text.toString().isEmpty()){
                binding.passwordSignup.error="*Required field"
            }
            if(binding.passwordSignup.editText!!.text.toString().isEmpty()){
                binding.passwordSignup.error="Password required"
            }
            if(binding.confirmPassSignup.editText!!.text.toString().isEmpty()){
                binding.confirmPassSignup.error="*Required field"
            }
            if(binding.passwordSignup.editText!!.text.toString()!=binding.confirmPassSignup.editText!!.text.toString()){
               Toast.makeText(this@SignUpActivity,"password not matched",Toast.LENGTH_LONG).show()
            }
            else if((binding.nameSignup.editText!!.text.toString().isNotEmpty()) && (binding.emailSignup.editText!!.text.toString().isNotEmpty())
                && (binding.passwordSignup.editText!!.text.toString().isNotEmpty()) && (binding.confirmPassSignup.editText!!.text.toString().isNotEmpty())
                && (binding.passwordSignup.editText!!.text.toString()==binding.confirmPassSignup.editText!!.text.toString())){

                val intent=Intent(this@SignUpActivity,LoginActivity::class.java)
                signEditor.putString("key_signupName",binding.nameSignup.editText!!.text.toString())
                signEditor.putString("key_signupEmail",binding.emailSignup.editText!!.text.toString())
                signEditor.putString("key_signupPassword",binding.passwordSignup.editText!!.text.toString())
                signEditor.commit()
                startActivity(intent)
                Toast.makeText(this@SignUpActivity,"Register Successfully",Toast.LENGTH_LONG).show()

            }

        }

    }

    private fun isValidEmail(email: Editable): Boolean {
        val Pattern = "[a-zA-Z0-9._-]+@[a-z]+\\.[a-z]{2,3}"
        return email.matches(Pattern.toRegex())
    }


}