package com.example.userenquiryapp


data class UserData(
    val firstName:String,
    val middleName:String,
    val lastName:String,
    val mobileNumber:String,
    val emailId:String,
    val dateOfBirth:String,
    val gender: String,
    val selectedLanguages: String,

    )

