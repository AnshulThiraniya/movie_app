package com.example.userenquiryapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.userenquiryapp.databinding.ActivityHistoryBinding


class HistoryActivity : AppCompatActivity() , DbListAdapter.OnItemLongClickListener{
   lateinit var listAdapter: DbListAdapter
   lateinit var recyclerView:RecyclerView
   lateinit var myDbAdapter:DataBaseClass
   lateinit var binding:ActivityHistoryBinding
   var myrowId:Int=-1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityHistoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        recyclerView=binding.recyclerListview
        recyclerView.layoutManager=LinearLayoutManager(this)
        setDataToList()


    }
    override fun onItemLongClick(position: Int) {
        registerForContextMenu(binding.recyclerListview)
        myrowId=position
    }

    override fun onResume() {
        super.onResume()
       setDataToList()

    }

   private fun setDataToList(){
       myDbAdapter=DataBaseClass(this)
        val temp=myDbAdapter.fetchData()
        listAdapter=DbListAdapter(temp,this)
        recyclerView.adapter=listAdapter
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        menuInflater.inflate(R.menu.context_menu_history,menu)
    }

    override fun onContextItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.cm_delete->{
                if (myrowId != -1) {
                    myDbAdapter.deleteSingleData(myrowId)
                    listAdapter.removeItem(myrowId)
                    Toast.makeText(this, "Deleted", Toast.LENGTH_LONG).show()
                }
            }
            R.id.cm_update->{
                val intent=Intent(this@HistoryActivity,MainActivity::class.java)
                startActivity(intent)

            }
        }

        return super.onContextItemSelected(item)
    }

}



