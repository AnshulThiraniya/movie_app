package com.example.userenquiryapp

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.Toast
import com.example.userenquiryapp.databinding.ActivityLoginBinding
import com.example.userenquiryapp.databinding.ActivityMainBinding

class LoginActivity : AppCompatActivity(), View.OnClickListener {
    lateinit var binding:ActivityLoginBinding
    lateinit var lgPrefrence:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnSkipLogin.setOnClickListener(this)
        binding.loginBtn.setOnClickListener(this)
        binding.loginLinkTextview.setOnClickListener(this)
        lgPrefrence=getSharedPreferences("SignUp_data",Context.MODE_PRIVATE)

        if (isUserLoggedIn()) {
            launchMainActivity()
            return
        }

    }

    private fun isUserLoggedIn(): Boolean {
        // Check if the user is logged in using SharedPreferences
        val sharedPreferences = getSharedPreferences("SignUp_data", Context.MODE_PRIVATE)
        return sharedPreferences.getBoolean("isLoggedIn", false)
    }

    private fun launchMainActivity() {
        val intent = Intent(this@LoginActivity, MainActivity::class.java)
        startActivity(intent)
        finish()
    }


    override fun onClick(view: View?) {
        when(view!!.id){
            R.id.login_btn->{
                val email=binding.emailLogin.editText!!.text.toString()
                val password=binding.passwordLogin.editText!!.text.toString()
                val savedEmail=lgPrefrence.getString("key_signupEmail","")
                val savedPassword=lgPrefrence.getString("key_signupPassword","")
                if(email==savedEmail && password==savedPassword && email.isNotEmpty() && password.isNotEmpty()){

                    val intent=Intent(this@LoginActivity,MainActivity::class.java)
                    startActivity(intent)
                    Toast.makeText(this,"login successfully",Toast.LENGTH_LONG).show()
                }
                else{
                    Toast.makeText(this@LoginActivity,"Invalid email or password",Toast.LENGTH_LONG).show()
                }
            }
            R.id.btn_skip_login->{
                val intent=Intent(this@LoginActivity,MainActivity::class.java)
                startActivity(intent)
            }
            R.id.login_link_textview->{
                val intent=Intent(this@LoginActivity,SignUpActivity::class.java)
                startActivity(intent)
            }


        }

    }
}