package com.example.userenquiryapp

class LocalKeys {
    companion object{
        val USER_DATA="user data"
    }
}