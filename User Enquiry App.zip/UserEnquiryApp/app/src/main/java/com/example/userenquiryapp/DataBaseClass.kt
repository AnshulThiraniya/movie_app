package com.example.userenquiryapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast


class DataBaseClass(context: Context) {


    private val mcontext:Context=context
    val DBNAME = "NewDatabase"
    val TABLE_NAME = "UserDataTable"
    val VERSION = 8

    val ID = "Id"
    val FNAME = "Fname"
    val MNAME="Mname"
    val LNAME = "Lname"
    val MOBILE_NO = "Mobile_no"
    val EMAIL_ID = "Email_id"
    val DOB = "DOB"
    val GENDER = "Gender"
    val TECHNOLOGY="Technology"


    val CREATE_TABLE =
        "CREATE TABLE $TABLE_NAME($ID INTEGER PRIMARY KEY AUTOINCREMENT,$FNAME TEXT,$MNAME TEXT,$LNAME TEXT,$MOBILE_NO TEXT,$EMAIL_ID TEXT,$DOB TEXT,$GENDER TEXT,$TECHNOLOGY TEXT) "


    val Sqlhelper=MyOpenHelperClass(context)
    val SqlDb=Sqlhelper.writableDatabase


    inner class MyOpenHelperClass(context: Context) : SQLiteOpenHelper(context, DBNAME, null, VERSION) {
        override fun onCreate(sqlLiteDb: SQLiteDatabase?) {
            sqlLiteDb?.execSQL(CREATE_TABLE)
        }

        override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
            p0?.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
            onCreate(p0)
        }
    }

    fun  createData(fname:String,mname:String,lname:String,mobile:String,email:String,dob:String,gender:String,Technology:String){

        val values=ContentValues()

        values.put(FNAME,fname)
        values.put(MNAME,mname)
        values.put(LNAME,lname)
        values.put(MOBILE_NO,mobile)
        values.put(EMAIL_ID,email)
        values.put(DOB,dob)
        values.put(GENDER,gender)
        values.put(TECHNOLOGY,Technology)


        SqlDb.insert(TABLE_NAME,null,values)

    }

    fun fetchData(): ArrayList<UserData> {
        val dataList = ArrayList<UserData>()
        val myCursor = SqlDb.rawQuery("SELECT * FROM $TABLE_NAME", null,null)

        if (myCursor.moveToFirst()) {
            do {

                val fname = myCursor.getString(0)
                val mname=myCursor.getString(1)
                val lname = myCursor.getString(2)
                val mobileNo = myCursor.getString(3)
                val emailId = myCursor.getString(4)
                val dob = myCursor.getString(5)
                val gender = myCursor.getString(6)
                val technology = myCursor.getString(7)

                val data = UserData(fname,mname, lname, mobileNo, emailId, dob, gender, technology)
                dataList.add(data)
            } while (myCursor.moveToNext())
        }

        return dataList
    }

    fun deleteSingleData(rowId:Int){
        val deletedRow=SqlDb.delete(TABLE_NAME,"$ID=$rowId",null)
        if(deletedRow>0){
            Toast.makeText(mcontext,"$deletedRow row delete",Toast.LENGTH_LONG).show()
        }
    }


    fun  updateData(id:Int,fname:String,mname:String,lname:String,mobile:String,email:String,dob:String,gender:String,Technology: String){

        val values=ContentValues()

        values.put(FNAME,fname)
        values.put(MNAME,mname)
        values.put(LNAME,lname)
        values.put(MOBILE_NO,mobile)
        values.put(EMAIL_ID,email)
        values.put(DOB,dob)
        values.put(GENDER,gender)
        values.put(TECHNOLOGY,Technology)


        SqlDb.update(TABLE_NAME,values,"$ID=$id",null)

    }


}
