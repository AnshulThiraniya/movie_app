package com.example.tmdbmovieapp.response

import com.example.tmdbmovieapp.datamodels.ApiData

class ResponseList:ArrayList<ApiData>()