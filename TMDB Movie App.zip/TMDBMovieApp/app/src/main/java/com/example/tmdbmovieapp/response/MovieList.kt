package com.example.tmdbmovieapp.response

import com.example.tmdbmovieapp.datamodels.MoviesResult

class MovieList:ArrayList<MoviesResult>()